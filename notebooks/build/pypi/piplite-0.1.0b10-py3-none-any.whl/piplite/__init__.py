"""A configurable Python package backed by Pyodide's micropip"""
from .piplite import install

__version__ = "0.1.0b10"

__all__ = ["install"]
